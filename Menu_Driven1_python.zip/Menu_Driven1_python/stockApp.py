'''
    Class Stock
        Each stock purchased will have 4 instance variables:
            •	stock name (a string)
            •	amount purchased in lot (an integer, where 1 lot refers to 1000 units)
            •	price purchased (per unit, a float, in RM) 
            •	date purchased (a string, where the format is “MM/DD/YYYY”).


'''

class Stock:
    def __init__ (self,stock_name,amount_purchased,price_purchased,date):
        self.stock_name = stock_name
        self.amount_purchased = amount_purchased
        self.price_purchased = price_purchased
        self.date = date
        
    def getName(self):
        return self.stock_name
    
    def getAmount(self):
        return self.amount_purchased
    
    def getPrice(self):
        return self.price_purchased
    
    def getDate(self):
        return self.date
    
    def setName(self,stock_name):
        self.stock_name = stock_name
        
    def setAmount(self,amount_purchased):
        self.amount_purchased = amount_purchased
    
    def setPrice(self,price_purchased):
        self.price_purchased = price_purchased
    
    def setDate(self,date):
        self.date = date
        
    
    def value(self):
        return self.amount_purchased * (self.price_purchased * 1000)

    def __eq__(self,stock1):

        if self.stock_name == stock1.stock_name:
            return True
        else:
            return False
        
    def __lt__(self,stock1):

        if self.value() < stock1.value():
            return True
        else:
            return False
        
    def __str__(self):
        #HELP (2 lots @RM2.35/unit) bought in 10/10/2010

        return(self.stock_name+ " (" + str(self.amount_purchased) + " lots @RM"+str(self.price_purchased)+"/unit) bought in "+self.date)

# Test stock
'''
s1 = Stock("stock1",2,2.35,"10/10/2010")
s2 = Stock("stock2",3,2.35,"10/10/2010")
print(s1)
print(s2)
'''

'''
    Class StockPortfolio
        The StockPortfolio class should have a
        client’s name (of type string),
        and a collection of Stock objects bought by the client
        no additional attribute is required

'''


class StockPortfolio:
    
    def __init__ (self,client_name,stocks=[]):

        self.client_name = client_name
        self.stocks = stocks

    def getName(self):
        return self.client_name
    
    def getStock(self):
        return self.stocks

    def setName(self,client_name):
        self.client_name = client_name

    def addStock(self,stock):
        self.stocks.append(stock)

    def noOfStocks(self):
        return len(self.stocks)
    
    def allStocks(self):
        allStk = ""
        for i in range(len(self.stocks)):
            allStk = allStk +"\n"+ str(self.stocks[i])

        return allStk
    
    def totalValue (self):
        sum1 = 0
        for i in range(self.noOfStocks()):
            sum1 =sum1 + self.stocks[i].value()

        return sum1
    
    def mostExpensiveStock(self):
        maxStock = self.stocks[0]
        for i in range(1,len(self.stocks)):
            if self.stocks[i].value() > maxStock.value():
                maxStock = self.stocks[i]
        return maxStock
    
    def stockSummary(self,stockName):
        TotalValue = 0
        stockCount = 0
        stkDetails = ""
        isFound = False
        
        for i in range(len(self.stocks)):
            if self.stocks[i].getName() == stockName:
                isFound = True
                stockCount = stockCount + 1
                TotalValue = TotalValue + self.stocks[i].value()
    #MISSING
                stkDetails = str(self.stocks[i].getName()+"("+str(self.stocks[i].amount_purchased)+" lots @RM"+str(self.stocks[i].price_purchased)+"/unit) bought in "+self.stocks[i].date)
                average = "RM"+str((TotalValue/stockCount))

        if  isFound == True:
            return (stockName,TotalValue,stockCount,average,stkDetails)
        else:
            return None
    
    def sellStock(self,loc):
        
        if loc < 1 or loc > self.noOfStocks():
            return None
        else:
            sold = self.stocks[loc]
            del self.stocks[loc - 1]
                                 
        return sold

    def sortedStocks(self,criteria):
        if criteria == "lots":
            return self.stocks.sort(key=lambda x: x.amount_purchased)
        elif criteria == "price":
            return self.stocks.sort(key=lambda x: x.price_purchased)
        elif criteria == "value":
            return self.stocks.sort(key=lambda x: x.value())
        else:
            return self.stocks

    def saveToFile(self,fileName):
        fileIn = open(fileName,"w")
        
        for i in range(len(self.stocks)):
            fileIn.write(self.stocks[i].getName()+","+str(self.stocks[i].amount_purchased)+","+str(self.stocks[i].price_purchased)+","+self.stocks[i].date+"\n")

        fileIn.close()

    def loadFromFile(self,fileName):
        fileIn = open(fileName,"r")
        stockList = list()
        for i in fileIn:
            items = i.split(",")
            s1 = Stock(items[0],int(items[1]),float(items[2]),items[3].replace("\n",''))
            stockList.append(s1)
                                 
        self.stocks = stockList
        
            
        fileIn.close()
            

# Test portfolio
'''
s1 = Stock("stock1",2,2.35,"10/10/2010")
s2 = Stock("stock2",3,1.35,"10/10/2010")
s3 = Stock("stock3",10,3.50,"10/10/2010")

s4 = Stock("stock3",1,3.50,"10/10/2010")

sp1 = StockPortfolio("Jackson Howard",[s3,s1,s2,s4])
print("Client’s name:",sp1.getName())
print("Number of stocks:",sp1.noOfStocks())
print("All stocks:",sp1.allStocks())
print("Total Value :$",sp1.totalValue())
print("Most Expensive Stock:",sp1.mostExpensiveStock())
print("Stocks summary:",sp1.stockSummary("stock3"))
sp1.saveToFile("Stocksummary.txt")
sp1.sortedStocks("price")
print("All stocks after sorting by price :",sp1.allStocks())

sp1.sortedStocks("lots")
print("All stocks after sorting by lots :",sp1.allStocks())

sp1.sortedStocks("value")
print("All stocks after sorting by value :",sp1.allStocks())

sp1.sellStock(2)
print("After Selling stocks at location 2 :",sp1.allStocks())

sp1.loadFromFile("Stocksummary.txt")
print("After loading stock from file Stocksummary.txt :",sp1.allStocks())

'''       
def menu():
    print("---------------------------------")
    print("1 Buy stock\n2 Display all stocks’ details\n3 Display summary information about stock list\n4 Display stocks with user-specified stock name\n"
        "5 Sell a stock based on a given index\n6 Display all stocks, sorted according to Stock values\n"
        "7 Load stock information from file\n8 Save stock information to file\n\n0 Quit")
    choice = int(input("Your choice?"))
    return choice 











        
    
    
            
        
    
         
        
        
    
    
     
