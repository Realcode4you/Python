from stockApp import *

def main():
    clienName = input("Enter client’s name:")
   
    sp1 = StockPortfolio(clienName,[])

    while True:
        print (f"\nStock portfolio for {clienName}")
        choice = menu()
        if choice == 1:
            print("Buying a new stock")
            stockName = input("Stock Name:")
            amount = int(input("Amount of Lots:"))
            price = float(input("Price:"))
            date = input("Date:")
            print("... bought successfully.")
            
            s1 = Stock(stockName,amount,price,date)
            sp1.addStock(s1)


        elif choice == 2:
            if sp1.noOfStocks() > 0:
                print("Details of all stocks:")
                print(sp1.allStocks())
            else:
                print("No stocks are in the list yet")
        elif choice == 3:
            print("Summary Information")
            print("Number of stocks:",sp1.noOfStocks())
            print("Total value: RM",sp1.totalValue(),sep='')
            print("Most expensive stock: ",sp1.mostExpensiveStock())
            print("with a total value of RM{:.2f}".format(sp1.mostExpensiveStock().value()))
            
        elif choice == 4:
            stockName = input("Stock Name:")
            print("The stocks are:")
            sm = sp1.stockSummary(stockName)
            if sm is not None:
                print(f"{sm[4]} with a total value of RM{sm[1]}")
                print(f"Average value of {sm[0]} stocks: {sm[3]}")
            else:
                print("No stock with that name could be found") 
            
            
            
        elif choice == 5:
                n = sp1.noOfStocks()
                loc = int(input(f"Stock to sell 1..{n}?"))
                if sp1.sellStock(loc) is not None:
                    print(sp1.allStocks(),"has been sold.")
                else:
                    print("Out of range...")  
        elif choice == 6:
            print("Sorting stocks")
            criteria = input("- criteria (lots, price, value)? ")
            sp1.sortedStocks(criteria)
            
            if criteria == "value":
                stocks1 = sp1.getStock()
                for i in range(len(stocks1)):
                    print(str(stocks1[i])+" with a total value of RM{:.2f}".format(stocks1[i].value()))
            else:
                print(sp1.allStocks())
                    
        elif choice == 7:
            fileName = input("File name to load from:")
            sp1.loadFromFile(fileName)
        elif choice == 8:
            if sp1.noOfStocks() > 0:
                fileName = input("File name to save to:")
                sp1.saveToFile(fileName)
            else:
                print("No stocks are in the list yet")
                
        elif choice == 0:
            print("Adios...")
            break
    

if __name__=="__main__":
    main()
